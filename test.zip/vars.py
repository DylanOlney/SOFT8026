global blogCount
global vidCount

blogCount = 0
vidCount = 0

