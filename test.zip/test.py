rtn = {}
rtn['blogCount'] = 0
rtn['vidCount'] = 0

def count(event, context):
    
    msg = event['data']['type']
    
    if msg=="blogpost":
       rtn['blogCount'] +=1

    if msg == "vidpost":
       rtn['vidCount'] +=1

    return rtn
