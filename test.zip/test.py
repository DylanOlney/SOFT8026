def count(event, context):
    return event
