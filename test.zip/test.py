def count(event, context):
    msg = event['data']['msg']
    return msg
