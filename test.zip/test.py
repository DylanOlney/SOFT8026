def hello(event, context):
  print (event)
  return 'Hi There!'
